import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pickup-drop',
  templateUrl: './pickup-drop.component.html',
  styleUrls: ['./pickup-drop.component.css']
})
export class PickupDropComponent implements OnInit {

 
  constructor() { }

  ngOnInit(): void {
  }

}
